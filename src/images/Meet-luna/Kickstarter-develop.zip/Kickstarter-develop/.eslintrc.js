module.exports = {
  extends: '@mate-academy/eslint-config',
};
